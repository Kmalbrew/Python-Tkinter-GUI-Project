"""
Name of program: FinalProject_KEY2140832.py
Author of program: Keyera Malbrew
Last date program was modified: August 19, 2026
Summary of the program's intent: A GUI application for a construction company 
to view, search, sort, and add projects while saving data to a file.
"""

import os
import time
import threading
import tkinter as tk
from tkinter import ttk, messagebox


# CLASS & OBJECT DEFINITION

# This class acts as a blueprint to create a single construction project

class ConstructionProject:
    
    def __init__(self, project_id, name, client, budget, status="Pending"):
        self.project_id = project_id
        self.name = name
        self.client = client
        self.budget = float(budget)
        self.status = status

    def to_dict(self):
        # Converts project info into a dictionary format
        return {
            "id": self.project_id,
            "name": self.name,
            "client": self.client,
            "budget": self.budget,
            "status": self.status
        }

    def to_file_string(self):
        # Converts project info into a single line of text for saving to a file
        return f"{self.project_id},{self.name},{self.client},{self.budget},{self.status}\n"


# MAIN GUI APPLICATION CLASS

# This class sets up the main window and runs the program

class ConstructionApp(tk.Tk):
    def __init__(self):
        super().__init__()
        
        self.title("Keyera's Construction Management Portal")
        self.geometry("700x550")
        
        self.projects_list = []
        self.projects_dict = {}

        script_dir = os.path.dirname(os.path.abspath(__file__))
        self.file_path = r"C:\Users\keyer\OneDrive\Documents\Rio Salado College\CIS 156 Python Programming\Final Project\finalproject_data.txt"

        if not os.path.exists(self.file_path):
            self.create_default_file()

        self.create_widgets()

        
        self.load_projects_from_file()

   
    # READING AND WRITING TEXT FILES
    
    def create_default_file(self):
    # Creates a text file with default sample data on the first run
        default_data = [
            "101,Commercial Highrise,Apex Corp,500000.0,In Progress\n",
            "102,Residential Remodel,Jane Doe,45000.0,Pending\n",
            "103,Bridge Repair,City Services,120000.0,Completed\n"
        ]
        with open(self.file_path, "w") as f:
            f.writelines(default_data)

    def load_projects_from_file(self):
    # Reads project data line-by-line from projects_data.txt
        self.projects_list.clear()
        self.projects_dict.clear()

        if not os.path.exists(self.file_path):
            messagebox.showwarning("File Missing", f"Could not find {self.file_path}. Please create it in your project folder.")
            return

        try:
            with open(self.file_path, "r") as f:
                for line in f:
                    line = line.strip()
                    if line:
                        parts = line.split(",")
                        if len(parts) == 5:
                            p_id, name, client, budget, status = parts
                            proj = ConstructionProject(p_id.strip(), name.strip(), client.strip(), float(budget.strip()), status.strip())
                            self.projects_list.append(proj)
                            self.projects_dict[p_id.strip()] = proj.to_dict()
            
            self.refresh_table()

        except Exception as e:
            messagebox.showerror("File Error", f"Error reading {self.file_path}: {e}")
    # Saves a single new project to the end of the text file

    def save_project_to_file(self, project):
        with open(self.file_path, "a") as f:
            f.write(project.to_file_string())



    # SORTING AND SEARCHING ALGORITHMS

    def sort_projects_by_budget(self):
        n = len(self.projects_list)
        
        # Loop through list to compare neighboring items
        for i in range(n):
            for j in range(0, n - i - 1):
                if self.projects_list[j].budget > self.projects_list[j + 1].budget:
                    self.projects_list[j], self.projects_list[j + 1] = (
                        self.projects_list[j + 1],
                        self.projects_list[j]
                    )
                    
        # Refresh screen table to display updated sorted order
        self.refresh_table()
        messagebox.showinfo("Sort Complete", "Projects sorted by budget from lowest to highest!")

    def search_project_by_id(self):
        target_id = self.search_entry.get().strip()
        
        # Check if user typed an ID
        if not target_id:
            messagebox.showwarning("Input Error", "Please enter a Project ID to search.")
            return

        found = None
        # Loop through list one project at a time to check for a matching ID
        for proj in self.projects_list:
            if proj.project_id == target_id:
                found = proj
                break 

        # Display result message
        if found:
            messagebox.showinfo(
                "Project Found", 
                f"ID: {found.project_id}\n"
                f"Name: {found.name}\n"
                f"Client: {found.client}\n"
                f"Budget: ${found.budget:,.2f}\n"
                f"Status: {found.status}"
            )
        else:
            messagebox.showerror("Not Found", f"No project found with ID: {target_id}")


    # MULTITHREADING

    def start_background_status_check(self):
        # Creates a thread pointing to our background task function
        thread = threading.Thread(target=self.background_status_task, daemon=True)
        thread.start()  # Run thread

    def background_status_task(self):

        self.status_label.config(text="Status Check: Checking projects in background...")
        time.sleep(3) 
        self.status_label.config(text=f"Status Check: All {len(self.projects_list)} projects verified!")


    # USER INTERFACE BUILDER

    def create_widgets(self):
        # Creates labels, text boxes, buttons, and tables on the window
        
        # Top banner frame
        header_frame = tk.Frame(self, bg="#2c3e50", pady=10)
        header_frame.pack(fill="x")

        # Try loading image header
        try:
            self.logo = tk.PhotoImage(file="logo.png")
            logo_label = tk.Label(header_frame, image=self.logo, bg="#2c3e50")
            logo_label.pack(side="left", padx=10)
        except Exception:
            pass  

        # Title Label
        title = tk.Label(
            header_frame, 
            text="Keyera's Construction Management Portal", 
            font=("Helvetica", 18, "bold"), 
            fg="white", 
            bg="#2c3e50"
        )
        title.pack(side="left", padx=10)

        # Input box section for adding new projects
        input_frame = tk.LabelFrame(self, text=" Add New Construction Project ", padx=10, pady=10)
        input_frame.pack(fill="x", padx=10, pady=5)

        tk.Label(input_frame, text="ID:").grid(row=0, column=0, sticky="w")
        self.id_entry = tk.Entry(input_frame, width=10)
        self.id_entry.grid(row=0, column=1, padx=5, pady=2)

        tk.Label(input_frame, text="Project Name:").grid(row=0, column=2, sticky="w")
        self.name_entry = tk.Entry(input_frame, width=15)
        self.name_entry.grid(row=0, column=3, padx=5, pady=2)

        tk.Label(input_frame, text="Client:").grid(row=1, column=0, sticky="w")
        self.client_entry = tk.Entry(input_frame, width=10)
        self.client_entry.grid(row=1, column=1, padx=5, pady=2)

        tk.Label(input_frame, text="Budget ($):").grid(row=1, column=2, sticky="w")
        self.budget_entry = tk.Entry(input_frame, width=15)
        self.budget_entry.grid(row=1, column=3, padx=5, pady=2)

        # Button to add project
        add_btn = tk.Button(input_frame, text="Add Project", bg="#27ae60", fg="white", command=self.add_project)
        add_btn.grid(row=1, column=4, padx=10)

        # Middle controls section for sorting, searching, and multithreading
        ctrl_frame = tk.Frame(self, pady=5)
        ctrl_frame.pack(fill="x", padx=10)

        sort_btn = tk.Button(ctrl_frame, text="Sort by Budget", command=self.sort_projects_by_budget)
        sort_btn.pack(side="left", padx=5)

        thread_btn = tk.Button(ctrl_frame, text="Run Background Check (Thread)", command=self.start_background_status_check)
        thread_btn.pack(side="left", padx=5)

        tk.Label(ctrl_frame, text="Search ID:").pack(side="left", padx=(15, 2))
        self.search_entry = tk.Entry(ctrl_frame, width=8)
        self.search_entry.pack(side="left", padx=2)

        search_btn = tk.Button(ctrl_frame, text="Search", command=self.search_project_by_id)
        search_btn.pack(side="left", padx=5)

        # Table to display projects
        table_frame = tk.Frame(self)
        table_frame.pack(fill="both", expand=True, padx=10, pady=5)

        columns = ("ID", "Name", "Client", "Budget", "Status")
        self.tree = ttk.Treeview(table_frame, columns=columns, show="headings", height=8)
        for col in columns:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=120, anchor="center")
        self.tree.pack(fill="both", expand=True)

        # Bottom status message bar
        self.status_label = tk.Label(self, text="Status Check: Idle", bd=1, relief="sunken", anchor="w")
        self.status_label.pack(side="bottom", fill="x")

    
    # BUTTON ACTION HANDLERS
    # Reads text from input boxes, creates a project, and saves it

    def add_project(self):
        p_id = self.id_entry.get().strip()
        name = self.name_entry.get().strip()
        client = self.client_entry.get().strip()
        budget_str = self.budget_entry.get().strip()

        if not (p_id and name and client and budget_str):
            messagebox.showwarning("Validation Error", "All fields must be filled!")
            return

        # Ensure budget is typed as a valid number
        try:
            budget = float(budget_str)
        except ValueError:
            messagebox.showerror("Type Error", "Budget must be a valid number.")
            return

        proj = ConstructionProject(p_id, name, client, budget, "Pending")
        
        self.projects_list.append(proj)
        self.projects_dict[p_id] = proj.to_dict()

        self.save_project_to_file(proj)

        self.refresh_table()
        
        # Clears input text boxes
        self.id_entry.delete(0, tk.END)
        self.name_entry.delete(0, tk.END)
        self.client_entry.delete(0, tk.END)
        self.budget_entry.delete(0, tk.END)

    def refresh_table(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        for p in self.projects_list:
            self.tree.insert("", "end", values=(p.project_id, p.name, p.client, f"${p.budget:,.2f}", p.status))



# MAIN EXECUTION POINT
# Launchs the application window

if __name__ == "__main__":
    app = ConstructionApp()
    app.mainloop()